/*
 Navicat Premium Data Transfer

 Source Server         : skl
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : community_question

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 02/04/2021 14:12:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for community_question
-- ----------------------------
DROP TABLE IF EXISTS `community_question`;
CREATE TABLE `community_question`  (
  `id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `user_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '发布者用户id',
  `nick_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '发布者用户昵称',
  `user_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '发布者头像url',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '问题标题',
  `md_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'md问题内容',
  `html_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'html问题内容',
  `view_count` int(11) DEFAULT 0 COMMENT '浏览次数',
  `thumhup` int(11) DEFAULT 0 COMMENT '点赞数',
  `reply` int(11) DEFAULT 0 COMMENT '回复数',
  `status` tinyint(3) DEFAULT 1 COMMENT '状态，0：已删除， 1：未解决，2：已解决',
  `create_date` datetime(0) DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_date` datetime(0) DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问题信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of community_question
-- ----------------------------
INSERT INTO `community_question` VALUES ('1361738671518146562', '9', 'shoukailiang', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/858cd29a03e74e91a2e7d188748c76c8.jpg', '如何学习java', '如何学习java', '<p>如何学习java</p>\n', 3, 1, 3, 1, '2021-02-17 02:06:13', '2021-02-17 02:06:13');
INSERT INTO `community_question` VALUES ('1361750767303680002', '1360616611496660993', 'AntMan', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/3f060bb8aa18427e9de5c35c40cdb672.png', '自学java，学多久可以自己找到工作？', '自学java，学多久可以自己找到工作？', '<p>自学java，学多久可以自己找到工作？</p>\n', 2, 0, 1, 1, '2021-02-17 02:54:17', '2021-02-17 02:54:17');
INSERT INTO `community_question` VALUES ('1376754228059533313', '1366056830396129282', 'arrow', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210305/260d4c5d6e1346c2afc5f5a0e4cacdfa.png', '人工智能2021年适合学吗', '# 2021年\n适合学习人工智能吗', '<h1><a id=\"2021_0\"></a>2021年</h1>\n<p>适合学习人工智能吗</p>\n', 1, 0, 0, 1, '2021-03-30 12:32:41', '2021-03-30 12:32:41');
INSERT INTO `community_question` VALUES ('1376848962232852482', '9', 'shoukailiang', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/858cd29a03e74e91a2e7d188748c76c8.jpg', 'vr是否值得学习', '# 如题\nvr是否值得学习', '<h1><a id=\"_0\"></a>如题</h1>\n<p>vr是否值得学习</p>\n', 1, 0, 0, 1, '2021-03-30 18:49:07', '2021-03-30 18:49:07');
INSERT INTO `community_question` VALUES ('1377199616134586369', '1366056830396129282', 'arrow', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210305/260d4c5d6e1346c2afc5f5a0e4cacdfa.png', '前端一年赚多少', '# 前端一年赚多少\n前端一年赚多少\n前端一年赚多少\n前端一年赚多少\n前端一年赚多少\n前端一年赚多少\n前端一年赚多少', '<h1><a id=\"_0\"></a>前端一年赚多少</h1>\n<p>前端一年赚多少<br />\n前端一年赚多少<br />\n前端一年赚多少<br />\n前端一年赚多少<br />\n前端一年赚多少<br />\n前端一年赚多少</p>\n', 1, 0, 0, 1, '2021-03-31 18:02:30', '2021-03-31 18:02:30');

-- ----------------------------
-- Table structure for community_question_label
-- ----------------------------
DROP TABLE IF EXISTS `community_question_label`;
CREATE TABLE `community_question_label`  (
  `id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `question_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '文章 id',
  `label_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '标签id',
  `create_date` datetime(0) DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '问题标签中间表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of community_question_label
-- ----------------------------
INSERT INTO `community_question_label` VALUES ('1361738671576866818', '1361738671518146562', '12', '2021-02-17 02:06:13');
INSERT INTO `community_question_label` VALUES ('1361738671576866819', '1361738671518146562', '1361734416111587330', '2021-02-17 02:06:13');
INSERT INTO `community_question_label` VALUES ('1361738671576866820', '1361738671518146562', '8', '2021-02-17 02:06:13');
INSERT INTO `community_question_label` VALUES ('1361738671576866821', '1361738671518146562', '11', '2021-02-17 02:06:13');
INSERT INTO `community_question_label` VALUES ('1361738671576866822', '1361738671518146562', '1361734336885379074', '2021-02-17 02:06:13');
INSERT INTO `community_question_label` VALUES ('1361750767307874305', '1361750767303680002', '9', '2021-02-17 02:54:17');
INSERT INTO `community_question_label` VALUES ('1361750767307874306', '1361750767303680002', '12', '2021-02-17 02:54:17');
INSERT INTO `community_question_label` VALUES ('1361750767307874307', '1361750767303680002', '1361734416111587330', '2021-02-17 02:54:17');
INSERT INTO `community_question_label` VALUES ('1361750767307874308', '1361750767303680002', '1361734236691845121', '2021-02-17 02:54:17');
INSERT INTO `community_question_label` VALUES ('1361750767307874309', '1361750767303680002', '1361734630004314113', '2021-02-17 02:54:17');
INSERT INTO `community_question_label` VALUES ('1376754228122447873', '1376754228059533313', '18', '2021-03-30 12:32:41');
INSERT INTO `community_question_label` VALUES ('1376754228122447874', '1376754228059533313', '20', '2021-03-30 12:32:41');
INSERT INTO `community_question_label` VALUES ('1376754228122447875', '1376754228059533313', '17', '2021-03-30 12:32:41');
INSERT INTO `community_question_label` VALUES ('1376754228122447876', '1376754228059533313', '19', '2021-03-30 12:32:41');
INSERT INTO `community_question_label` VALUES ('1376848962308349954', '1376848962232852482', '20', '2021-03-30 18:49:07');
INSERT INTO `community_question_label` VALUES ('1376848962316738561', '1376848962232852482', '17', '2021-03-30 18:49:07');
INSERT INTO `community_question_label` VALUES ('1377199616243638274', '1377199616134586369', '3', '2021-03-31 18:02:30');
INSERT INTO `community_question_label` VALUES ('1377199616247832577', '1377199616134586369', '1244923532817915906', '2021-03-31 18:02:30');
INSERT INTO `community_question_label` VALUES ('1377199616247832578', '1377199616134586369', '6', '2021-03-31 18:02:30');
INSERT INTO `community_question_label` VALUES ('1377199616247832579', '1377199616134586369', '1', '2021-03-31 18:02:30');

-- ----------------------------
-- Table structure for community_replay
-- ----------------------------
DROP TABLE IF EXISTS `community_replay`;
CREATE TABLE `community_replay`  (
  `id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `parent_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '-1 表示正常回答，其他值表示是回答的回复',
  `user_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回答者id',
  `nick_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回答者用户昵称',
  `user_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回答者头像url',
  `question_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '问题id',
  `md_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'md问题内容',
  `html_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'html问题内容',
  `create_date` datetime(0) DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '回答信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of community_replay
-- ----------------------------
INSERT INTO `community_replay` VALUES ('1361743981817389057', '-1', '9', 'shoukailiang', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/858cd29a03e74e91a2e7d188748c76c8.jpg', '1361738671518146562', '大家快来提问呀', '<p>大家快来提问呀</p>\n', '2021-02-17 02:27:19');
INSERT INTO `community_replay` VALUES ('1361750140901154818', '-1', '1360616611496660993', 'AntMan', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/3f060bb8aa18427e9de5c35c40cdb672.png', '1361738671518146562', '学习java要一步一个脚印', '<p>学习java要一步一个脚印</p>\n', '2021-02-17 02:51:48');
INSERT INTO `community_replay` VALUES ('1361750335449751554', '1361743981817389057', '1360616611496660993', 'AntMan', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210217/3f060bb8aa18427e9de5c35c40cdb672.png', '1361738671518146562', '', '[哈哈]多看看视频', '2021-02-17 02:52:34');
INSERT INTO `community_replay` VALUES ('1376755461117800449', '-1', '1366056830396129282', 'arrow', 'https://vue-community.oss-cn-hangzhou.aliyuncs.com/articel/20210305/260d4c5d6e1346c2afc5f5a0e4cacdfa.png', '1361750767303680002', '# 如题\n我觉得至少得8个月吧！！！', '<h1><a id=\"_0\"></a>如题</h1>\n<p>我觉得至少得8个月吧！！！</p>\n', '2021-03-30 12:37:35');

SET FOREIGN_KEY_CHECKS = 1;
